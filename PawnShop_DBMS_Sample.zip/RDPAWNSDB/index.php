
<!DOCTYPE html>
<html>
<body>

<style>

body{
            content: '';
            position: fixed;
            width: 100vw;
            height: 100vh;
            background-image: url("RDPAWN_HEAD.jpg");
            background-position: center center;
            background-repeat: no-repeat;
            background-attachment: fixed;
            background-size: cover;
            background-image: blur(25px)); }
 label {
	
        display: inline-block;
        width: 150px;
        color: solid black;
		font-size: 120%;
 }

select{
	background-color : #d1d1d1; 
	float:center;
    width:80%;
    border:2px solid #dadada;
    border-radius:9px;
    font-size:20px;
    padding:5px;
    margin-top:-10px; 
}


  input {
    float:center;
    width:80%;
    border:2px solid #dadada;
    border-radius:9px;
    font-size:20px;
    padding:5px;
    margin-top:-10px;    
}
input[type="text"],textarea {

  background-color : #d1d1d1; 

}
input[type="tel"],textarea {

background-color : #d1d1d1; }
input[type="email"],textarea {

background-color : #d1d1d1;}
input[type="number"],textarea {

background-color : #d1d1d1;}
input[type="date"],textarea {
width: 30%;
background-color : #d1d1d1;}

fieldset{
	border:2px solid ;
    border-radius:9px;
}
  ::placeholder {
color: gray;
text-align: center;
  }
  
  
</style>
<br><br><br><br>
<html>
<body>
<center>	
<fieldset style="width: 50%; padding-top: 10px; padding-bottom: 1%; background: #E5E4E2; border-width: 10px; ">
<legend style="background-color: red;border-radius:9px;font-size: 40px" align="center">RD PAWNSHOP</legend>
<fieldset style=" padding-top: 10px; padding-bottom: 5%; background: #E5E4E2; border-width: 10px; ">

	<form method="post" action="view.php">
		
		<label>Sender's Name</label><br><br>
		<input type="text" name="sendername" placeholder="Complete Name" required>
		<br><br>
		<label>Sender's Number: </label><br><br>
		<input type="tel" name="sendernumber" placeholder="Your Number" required>
		<br><br>
		<label>Receiver's Name:</label><br><br>
		<input type="text" name="receivername" placeholder="Reciever's Name" required>
		<br><br>
		<label>Receiver's Number:</label><br><br>
		<input type="tel" name="receivernumber" placeholder="Reciver's Number" required>
		<br><br>
		<label>Trucking Code:</label> <br><br>
		<input type="text" name="truckingcode" placeholder="Trucking Code" required>
		<br><br>
		<label>Amount:</label> <br><br>
		<input type="text" name="amount" placeholder="Amount" required>
		<br><br>
		
		
		
		<br><br>
		<input type="submit" name="save" value="submit">
	</form>
	</fieldset>

<a href="view.php">View Data</a>

	</center>
	
  </body>
</html>
