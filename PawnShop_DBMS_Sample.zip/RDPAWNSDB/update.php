<?php

include('config.php');

if (isset($_POST['update']))
{		
	 $id=$_POST['mem_id'];
	 $sendername =mysqli_real_escape_string($db, $_POST['sendername']);
	 $sendernumber =mysqli_real_escape_string($db, $_POST['sendernumber']);
	 $receivername = mysqli_real_escape_string($db, $_POST['receivername']);
	 $receivernumber =mysqli_real_escape_string($db, $_POST['receivernumber']);
	 $truckingcode = mysqli_real_escape_string($db, $_POST['truckingcode']);
	 $amount =mysqli_real_escape_string ($db, $_POST['amount']);
	 

mysqli_query($db,"UPDATE members SET sendername='$sendername', sendernumber='$sendernumber' ,receivername='$receivername', receivernumber='$receivernumber', truckingcode='$truckingcode', amount='$amount' WHERE mem_id='$id'");
header("Location:view.php");
}


if (isset($_GET['id']) && is_numeric($_GET['id']) && $_GET['id'] > 0)
{

$id = $_GET['id'];
$result = mysqli_query($db,"SELECT * FROM members WHERE mem_id=".$_GET['id']);

$row = mysqli_fetch_array($result);

if($row)
{
	 $id = $row['mem_id'];
	 $sendername = $row['sendername'];
	 $sendernumber = $row['sendernumber'];
	 $receivername = $row['receivername'];
	 $receivernumber = $row['receivernumber'];
	 $truckingcode = $row['truckingcode'];
	 $amount = $row['amount'];
	

}
else
{
echo "No results!";
}
}

?>


<html>
<head>
<title>UPDATE</title>
</head>
<body>
<center>
<style>
body{
            content: '';
            position: fixed;
            width: 100vw;
            height: 100vh;
            background-image: url("RDPAWN_HEAD.jpg");
            background-position: center center;
            background-repeat: no-repeat;
            background-attachment: fixed;
            background-size: cover;
            background-image: blur(25px)); }
			table {
width: -moz-fit-content;
  width: fit-content;
  background-color: #8ca0ff;
  padding: 5px;
  margin-bottom: 1em;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding:20px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}
</style>


<form action="" method="post" action="view.php">
<input type="hidden" name="mem_id" value="<?php echo $id; ?>"/>

<table border="1">
<tr>
<td colspan="2"><b><font color='Red'>EDIT DATA </font></b></td>
</tr>

<tr>
<td width="179"><b><font >Sender's Name<em>*</em></font></b></td>
<td><label>
<input type="text" name="sendername" value="<?php echo $sendername; ?>" />
</label></td>
</tr>

<tr>
<td width="179"><b><font color='#663300'>Sender's Number<em>*</em></font></b></td>
<td><label>
<input type="tel" name="sendernumber" value="<?php echo $sendernumber ?>" />
</label></td>
</tr>

<tr>
<td width="179"><b><font color='#663300'>Receiver's Name<em>*</em></font></b></td>
<td><label>
<input type="text" name="receivername" value="<?php echo $receivername;?>" />
</label></td>
</tr>

<tr>
<td width="179"><b><font color='#663300'>Receiver's Number<em>*</em></font></b></td>
<td><label>
<input type="tel" name="receivernumber" value="<?php echo $receivernumber;?>" />
</label></td>
</tr>

<tr>
<td width="179"><b><font color='#663300'>Trucking Code<em>*</em></font></b></td>
<td><label>
<input type="text" name="truckingcode" value="<?php echo $truckingcode;?>" />
</label></td>
</tr>

<tr>
<td width="179"><b><font color='#663300'>Amount<em>*</em></font></b></td>
<td><label>
<input type="text" name="amount" value="<?php echo $amount;?>" />
</label></td>
</tr>



<tr align="Right">
<td colspan="2"><label>
<input type="submit" name="update" value="Edit Records">

</label></td>
</tr>
</table>
</form>
</center>
</body>
</html>
