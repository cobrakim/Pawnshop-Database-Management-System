<?php

include_once 'database.php';
if(isset($_POST['save']))
{	 
	 $sendername = $_POST['sendername'];
	 $sendernumber = $_POST['sendernumber'];
	 $receivername = $_POST['receivername'];
	 $receivernumber = $_POST['receivernumber'];
	 $truckingcode = $_POST['truckingcode'];
	 $amount = $_POST['amount'];
	 
	 
	 
	 $sql = "INSERT INTO members (sendername, sendernumber, receivername, receivernumber, truckingcode, amount)
	 VALUES ('$sendername','$sendernumber','$receivername','$receivernumber','$truckingcode','$amount')";
	 if (mysqli_query($conn, $sql)) {
		echo "New record created successfully !";
	 } else {
		echo "Error: " . $sql . "
" . mysqli_error($conn);
	 }
	 mysqli_close($conn);
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Table with database</title>
</head>
<body>
<center>
<table>
<style>
body{
            content: '';
            position: fixed;
            width: 100vw;
            height: 100vh;
            background-image: url("RDPAWN_HEAD.jpg");
            background-position: center center;
            background-repeat: no-repeat;
            background-attachment: fixed;
            background-size: cover;
            background-image: blur(25px)); }
table {
width: -moz-fit-content;
  width: fit-content;
  background-color: #8ca0ff;
  padding: 5px;
  margin-bottom: 1em;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding:20px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}

</style>

  <hr class="rounded"><hr class="rounded"><hr class="rounded">                      
                   
                                       
                                            <thead class="text-uppercase">
                                                <tr class="table-active">
													<th scope="col">ID</th>
                                                    <th scope="col">Sender's Name</th>
                                                    <th scope="col">Sender's Number</th>
                                                    <th scope="col">Receiver's Name</th>
                                                    <th scope="col">Receiver's Number</th>
													<th scope="col">Trucking Code</th> 
                                                    <th scope="col">Amount</th> 
                                                </tr>
                                            </thead>
											
                                            <tbody>
<?php 
               $conn = new mysqli("localhost","root","","rdpawndb");
               $sql = "SELECT * FROM members";
               $result = $conn->query($sql);
					$count=0;
               if ($result -> num_rows >  0) {
				  
                 while ($row = $result->fetch_assoc()) 
				 {
					  $count=$count+1;
                   ?>
                  
                   
                   <tr>
                    <th><?php echo $count ?></th>
                      <th><?php echo $row["sendername"] ?></th>
                      <th><?php echo $row["sendernumber"]  ?></th>
                      <th><?php echo $row["receivername"]  ?></th>
					  <th><?php echo $row["receivernumber"]  ?></th>
					  <th><?php echo $row["truckingcode"]  ?></th>
					  <th><?php echo $row["amount"]  ?></th>
					 
			
					  <th> <a href="up"edit></a><a href="update.php?id=<?php echo $row["mem_id"] ?>">Update</a> <a href="up"edit></a><a href="delete.php?id=<?php echo $row["mem_id"] ?>">Delete</a></th>
                    
                      
                    </tr>
<?php
                }
			   }
             ?>







			 
</table>
<a href="index.php">Add New</a>	
</center>
</body>
</html>

 